#!/bin/bash
echo "📦 Prüfe Node-Module..."
if [ ! -d "node_modules/lavalink-client" ]; then
  echo "📥 Installiere Abhängigkeiten..."
  npm install --no-audit --no-fund
  echo "✅ Installation fertig!"
else
  echo "✅ Module bereits installiert."
fi
echo ""
echo "🚀 Starte Bot..."
node src/index.js
