const { SlashCommandBuilder } = require("discord.js");
const { getOrCreatePlayer, isNodeConnected } = require("../utils/LavalinkManager");
const { buildErrorEmbed, buildAddedEmbed } = require("../utils/EmbedBuilder");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("play")
    .setDescription("🎵 Spielt einen Song – YouTube, Spotify, Shorts, Playlist")
    .addStringOption(o => o.setName("query").setDescription("Link oder Suchbegriff").setRequired(true)),

  async execute(interaction, client) {
    await interaction.deferReply();

    const voiceChannel = interaction.member?.voice?.channel;
    if (!voiceChannel) return interaction.editReply({ embeds: [buildErrorEmbed("Du musst in einem Voice-Channel sein!")] });

    const perms = voiceChannel.permissionsFor(client.user);
    if (!perms.has("Connect") || !perms.has("Speak"))
      return interaction.editReply({ embeds: [buildErrorEmbed("Keine Rechte für diesen Voice-Channel!")] });

    if (!isNodeConnected()) {
      return interaction.editReply({ embeds: [buildErrorEmbed("Musik-Server verbindet noch... Bitte in 10-15 Sekunden erneut versuchen.")] });
    }

    const query = interaction.options.getString("query");

    let queue;
    try {
      queue = await getOrCreatePlayer(interaction.guildId, voiceChannel, interaction.channel, client);
    } catch (err) {
      return interaction.editReply({ embeds: [buildErrorEmbed(`Verbindungsfehler: ${err.message}`)] });
    }
    queue.textChannel = interaction.channel;

    const isUrl = query.startsWith("http");
    await interaction.editReply(`🔍 ${isUrl ? "Lade Link" : `Suche nach **${query}**`}...`);

    const result = await queue._raw.search({ query }, interaction.user).catch(err => {
      console.error("[Search Error]", err.message);
      return null;
    });

    if (!result?.tracks?.length) {
      return interaction.editReply({ embeds: [buildErrorEmbed("Keine Ergebnisse gefunden!")] });
    }

    const isPlaying = queue.playing;

    if (result.loadType === "playlist") {
      queue._raw.queue.add(result.tracks);
      if (!isPlaying) await queue.play();
      return interaction.editReply({
        content: "",
        embeds: [{ color: 0x5865F2, description: `✅ **${result.tracks.length}** Songs aus **${result.playlist?.title || "Playlist"}** hinzugefügt!` }],
      });
    }

    const track = result.tracks[0];
    queue.addTrack(track);

    if (!isPlaying) {
      await queue.play();
      await interaction.deleteReply().catch(() => {});
    } else {
      const song = {
        title: track.info.title, artist: track.info.author,
        duration: Math.floor(track.info.length / 1000),
        url: track.info.uri, thumbnail: track.info.artworkUrl,
        source: track.info.sourceName || "youtube", requestedBy: interaction.user.username,
      };
      await interaction.editReply({ content: "", embeds: [buildAddedEmbed(song, queue.getSongCount(), queue)] });
    }
  },
};
