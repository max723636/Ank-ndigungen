const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("replay").setDescription("🔄 Startet den aktuellen Song von vorne"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    try {
      await q.seek(0);
      await interaction.reply({ content: `🔄 **${q.current.title}** von vorne gestartet!` });
    } catch (err) {
      await interaction.reply({ embeds: [buildErrorEmbed(`Konnte nicht zurückspulen: ${err.message}`)], flags: 64 });
    }
  },
};
