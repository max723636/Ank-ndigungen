const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");

module.exports = {
  data: new SlashCommandBuilder().setName("filter").setDescription("🎛️ Echte Audiofilter (Lavalink-nativ)"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    const select = new StringSelectMenuBuilder().setCustomId("filter_select").setPlaceholder("Filter wählen...")
      .addOptions(
        { label: "🚫 Kein Filter", value: "none" },
        { label: "🌙 Nightcore", value: "nightcore" },
        { label: "🌊 Vaporwave", value: "vaporwave" },
        { label: "🎸 Bass Boost", value: "bassboost" },
        { label: "📻 8D Audio", value: "8d" },
      );
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle("🎛️ Audiofilter").setDescription("Wähle einen Filter (wirkt sofort, server-seitig):")],
      components: [new ActionRowBuilder().addComponents(select)], flags: 64,
    });
  },
  async handleSelect(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?._raw) return interaction.update({ embeds: [buildErrorEmbed("Kein aktiver Song!")], components: [] });
    const key = interaction.values[0];
    const player = q._raw;

    try {
      switch (key) {
        case "nightcore":
          await player.filterManager.toggleNightcore();
          break;
        case "vaporwave":
          await player.filterManager.toggleVaporwave();
          break;
        case "bassboost":
          await player.filterManager.toggleBoostFilter?.() ?? await player.filterManager.setEQ(
            [0,1,2,3].map(band => ({ band, gain: 0.25 }))
          );
          break;
        case "8d":
          await player.filterManager.toggleRotation();
          break;
        default:
          await player.filterManager.resetFilters();
      }
      await interaction.update({ content: `🎛️ Filter **${key}** angewendet!`, embeds: [], components: [] });
    } catch (err) {
      console.error("[Filter]", err.message);
      await interaction.update({ content: `❌ Filter-Fehler: ${err.message}`, embeds: [], components: [] });
    }
  },
};
