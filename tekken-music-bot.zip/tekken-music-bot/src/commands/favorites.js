const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require("discord.js");
const { getFavorites } = require("../utils/FavoritesStore");
const { getOrCreatePlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");

const PER_PAGE = 5;

function buildEmbed(favorites, page, userTag) {
  const start    = page * PER_PAGE;
  const chunk    = favorites.slice(start, start + PER_PAGE);
  const maxPages = Math.ceil(favorites.length / PER_PAGE) || 1;

  const desc = chunk.length
    ? chunk.map((f, i) => `\`${start + i + 1}.\` [${f.title}](${f.url}) – ${f.artist}`).join("\n")
    : "*Noch keine Favoriten! Nutze `/favorite` während ein Song läuft.*";

  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(`⭐ Favoriten von ${userTag}`)
    .setDescription(desc)
    .setFooter({ text: `Seite ${page + 1}/${maxPages} • ${favorites.length} Songs gespeichert` });
}

function buildComponents(favorites, page, userId) {
  const start    = page * PER_PAGE;
  const chunk    = favorites.slice(start, start + PER_PAGE);
  const maxPages = Math.ceil(favorites.length / PER_PAGE) || 1;
  const rows     = [];

  if (chunk.length) {
    const select = new StringSelectMenuBuilder()
      .setCustomId(`favplay_${userId}_${page}`)
      .setPlaceholder("🎵 Song abspielen...")
      .addOptions(chunk.map((f, i) => ({
        label:       f.title.slice(0, 100),
        description: (f.artist || "Unbekannt").slice(0, 100),
        value:       String(start + i),
        emoji:       "🎵",
      })));
    rows.push(new ActionRowBuilder().addComponents(select));
  }

  if (maxPages > 1) {
    rows.push(new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`favprev_${userId}_${page}`).setEmoji("◀️").setLabel("Zurück").setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
      new ButtonBuilder().setCustomId(`favnext_${userId}_${page}`).setEmoji("▶️").setLabel("Weiter").setStyle(ButtonStyle.Secondary).setDisabled(page >= maxPages - 1),
    ));
  }

  return rows;
}

module.exports = {
  data: new SlashCommandBuilder().setName("favorites").setDescription("⭐ Zeigt deine Lieblingssongs"),

  async execute(interaction, client) {
    const favorites = getFavorites(interaction.user.id);
    await interaction.reply({
      embeds:     [buildEmbed(favorites, 0, interaction.user.username)],
      components: buildComponents(favorites, 0, interaction.user.id),
      flags: 64,
    });
  },

  // Seiten-Buttons (favprev_/favnext_)
  async handleButton(interaction, client) {
    const [prefix, userId, pageStr] = interaction.customId.split("_");
    if (interaction.user.id !== userId) {
      return interaction.reply({ content: "❌ Das sind nicht deine Favoriten!", flags: 64 });
    }
    const favorites = getFavorites(userId);
    let page = parseInt(pageStr);
    page = prefix === "favnext" ? page + 1 : page - 1;

    await interaction.update({
      embeds:     [buildEmbed(favorites, page, interaction.user.username)],
      components: buildComponents(favorites, page, userId),
    });
  },

  // Play-Auswahl (Select Menu, favplay_)
  async handleSelect(interaction, client) {
    const [, userId] = interaction.customId.split("_");
    if (interaction.user.id !== userId) {
      return interaction.reply({ content: "❌ Das sind nicht deine Favoriten!", flags: 64 });
    }

    const favorites = getFavorites(userId);
    const idx  = parseInt(interaction.values[0]);
    const song = favorites[idx];
    if (!song) return interaction.update({ content: "❌ Song nicht gefunden!", embeds: [], components: [] });

    const voiceChannel = interaction.member?.voice?.channel;
    if (!voiceChannel) return interaction.update({ embeds: [buildErrorEmbed("Du musst in einem Voice-Channel sein!")], components: [] });

    let queue;
    try {
      queue = await getOrCreatePlayer(interaction.guildId, voiceChannel, interaction.channel, client);
    } catch (err) {
      return interaction.update({ embeds: [buildErrorEmbed(err.message)], components: [] });
    }
    queue.textChannel = interaction.channel;

    const result = await queue._raw.search({ query: song.url }, interaction.user).catch(() => null);
    if (!result?.tracks?.length) {
      return interaction.update({ content: "❌ Song konnte nicht geladen werden!", embeds: [], components: [] });
    }

    const track   = result.tracks[0];
    const wasIdle = !queue.playing;
    queue.addTrack(track);
    if (wasIdle) await queue.play();

    await interaction.update({
      content: wasIdle ? `▶️ Spiele: **${song.title}**` : `✅ **${song.title}** zur Queue hinzugefügt!`,
      embeds: [], components: [],
    });
  },
};
