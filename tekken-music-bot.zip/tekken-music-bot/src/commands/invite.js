const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const config = require("../config");
module.exports = {
  data: new SlashCommandBuilder().setName("invite").setDescription("🔗 Einladungslink"),
  async execute(interaction, client) {
    const url = `https://discord.com/api/oauth2/authorize?client_id=${config.CLIENT_ID}&permissions=274881383424&scope=bot%20applications.commands`;
    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(config.COLORS.DEFAULT)
        .setTitle("🔗 Bot einladen")
        .setDescription(`[➡️ Hier klicken um den Bot einzuladen](${url})`)
        .setThumbnail(client.user.displayAvatarURL())],
      flags: 64,
    });
  },
};
