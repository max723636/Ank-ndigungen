const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("247").setDescription("🔁 Dauerbetrieb an/aus - Bot bleibt permanent im Sprachkanal"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q) return interaction.reply({ embeds: [buildErrorEmbed("Ich bin in keinem Voice-Channel! Starte erst /play.")], flags: 64 });
    q.stay247 = !q.stay247;
    await interaction.reply({
      content: q.stay247
        ? "🔁 **Dauerbetrieb aktiviert!** Ich bleibe im Channel, auch wenn niemand hört oder die Queue leer ist."
        : "🔁 **Dauerbetrieb deaktiviert.** Ich verlasse den Channel wieder bei Inaktivität.",
    });
  },
};
