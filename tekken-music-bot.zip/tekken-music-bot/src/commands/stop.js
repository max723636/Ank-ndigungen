const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("stop").setDescription("⏹️ Stoppt und leert die Queue"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    q.stop();
    await interaction.reply({ content: "⏹️ Gestoppt und Queue geleert!" });
  },
};
