const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
const { toggleFavorite } = require("../utils/FavoritesStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("favorite")
    .setDescription("⭐ Aktuellen Song favorisieren/entfavorisieren"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });

    const song = q.current;
    const isNowFavorite = toggleFavorite(interaction.user.id, song);

    await interaction.reply({
      content: isNowFavorite
        ? `⭐ **${song.title}** zu deinen Favoriten hinzugefügt!`
        : `💔 **${song.title}** aus deinen Favoriten entfernt.`,
      flags: 64,
    });
  },
};
