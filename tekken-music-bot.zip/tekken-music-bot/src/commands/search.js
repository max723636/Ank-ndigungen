const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require("discord.js");
const { getOrCreatePlayer, getPlayer } = require("../utils/LavalinkManager");
const { formatDuration, buildErrorEmbed } = require("../utils/EmbedBuilder");
const cache = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName("search")
    .setDescription("🔍 Sucht einen Song und zeigt eine Auswahlliste")
    .addStringOption(o => o.setName("query").setDescription("Suchbegriff").setRequired(true)),

  async execute(interaction, client) {
    await interaction.deferReply();

    const voiceChannel = interaction.member?.voice?.channel;
    if (!voiceChannel) return interaction.editReply({ embeds: [buildErrorEmbed("Du musst in einem Voice-Channel sein!")] });

    // Suche läuft über einen Player - der existiert entweder schon,
    // oder wird hier (mit Verbindung) neu erstellt.
    let queue;
    try {
      queue = await getOrCreatePlayer(interaction.guildId, voiceChannel, interaction.channel, client);
    } catch (err) {
      return interaction.editReply({ embeds: [buildErrorEmbed(`Verbindungsfehler: ${err.message}`)] });
    }

    const query  = interaction.options.getString("query");
    const result = await queue._raw.search({ query }, interaction.user).catch(err => {
      console.error("[Search Error]", err.message);
      return null;
    });
    if (!result?.tracks?.length) return interaction.editReply({ embeds: [buildErrorEmbed("Keine Ergebnisse!")] });

    const tracks = result.tracks.slice(0, 10);
    const key    = interaction.id;
    cache.set(key, tracks);
    setTimeout(() => cache.delete(key), 60_000);

    const select = new StringSelectMenuBuilder()
      .setCustomId("search_select")
      .setPlaceholder("🎵 Song auswählen...")
      .addOptions(tracks.map((t, i) => ({
        label:       t.info.title.slice(0, 100),
        description: `${t.info.author} • ${formatDuration(Math.floor(t.info.length/1000))}`.slice(0, 100),
        value:       `${key}_${i}`,
        emoji:       "🎵",
      })));

    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle(`🔍 ${query}`).setDescription("Wähle einen Song:")],
      components: [new ActionRowBuilder().addComponents(select)],
    });
  },

  async handleSelect(interaction, client) {
    const parts = interaction.values[0].split("_");
    const idx    = parseInt(parts.pop());
    const key    = parts.join("_");
    const tracks = cache.get(key);
    if (!tracks) return interaction.update({ embeds: [buildErrorEmbed("Abgelaufen! Erneut suchen.")], components: [] });

    const track        = tracks[idx];
    const voiceChannel = interaction.member?.voice?.channel;
    if (!voiceChannel) return interaction.update({ embeds: [buildErrorEmbed("Kein Voice-Channel!")], components: [] });

    let queue;
    try {
      queue = await getOrCreatePlayer(interaction.guildId, voiceChannel, interaction.channel, client);
    } catch (err) {
      return interaction.update({ embeds: [buildErrorEmbed(err.message)], components: [] });
    }
    queue.textChannel = interaction.channel;
    queue.addTrack(track);

    if (!queue.playing) {
      await queue.play();
      await interaction.update({ content: `▶️ Spiele: **${track.info.title}**`, embeds: [], components: [] });
    } else {
      await interaction.update({ content: `✅ **${track.info.title}** hinzugefügt! (#${queue.getSongCount()})`, embeds: [], components: [] });
    }
    cache.delete(key);
  },
};
