const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildQueueEmbed, buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder()
    .setName("queue").setDescription("📋 Zeigt die Queue")
    .addIntegerOption(o => o.setName("seite").setDescription("Seite").setMinValue(1)),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current && !q?.getSongCount()) return interaction.reply({ embeds: [buildErrorEmbed("Queue leer!")], flags: 64 });
    const page = (interaction.options.getInteger("seite") || 1) - 1;
    const maxPages = Math.ceil(q.getSongCount() / 10) || 1;
    const safe = Math.min(page, maxPages - 1);
    const comps = [];
    if (maxPages > 1) {
      comps.push(new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`qp_${safe}`).setEmoji("◀️").setLabel("Zurück").setStyle(ButtonStyle.Secondary).setDisabled(safe===0),
        new ButtonBuilder().setCustomId(`qn_${safe}`).setEmoji("▶️").setLabel("Weiter").setStyle(ButtonStyle.Secondary).setDisabled(safe>=maxPages-1),
      ));
    }
    await interaction.reply({ embeds: [buildQueueEmbed(q, safe)], components: comps });
  },
};
