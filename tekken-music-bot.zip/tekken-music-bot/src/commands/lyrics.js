const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
const config = require("../config");
module.exports = {
  data: new SlashCommandBuilder()
    .setName("lyrics").setDescription("📝 Lyrics des aktuellen oder gesuchten Songs")
    .addStringOption(o => o.setName("song").setDescription("Song (leer = aktueller Song)")),
  async execute(interaction, client) {
    await interaction.deferReply();
    const q     = getPlayer(interaction.guildId, client);
    const input = interaction.options.getString("song");
    const term  = input || (q?.current ? `${q.current.title} ${q.current.artist}` : null);
    if (!term) return interaction.editReply({ embeds: [buildErrorEmbed("Kein Song angegeben!")] });
    if (!config.GENIUS_TOKEN) return interaction.editReply({ embeds: [buildErrorEmbed("GENIUS_TOKEN in .env nicht gesetzt!")] });
    try {
      const { Client: Genius } = require("genius-lyrics");
      const genius  = new Genius(config.GENIUS_TOKEN);
      const results = await genius.songs.search(term);
      if (!results.length) return interaction.editReply({ embeds: [buildErrorEmbed(`Keine Lyrics für: **${term}**`)] });
      const song   = results[0];
      const lyrics = await song.lyrics();
      const text   = lyrics.length > 3800 ? lyrics.slice(0, 3800) + "\n\n*... (zu lang)*" : lyrics;
      await interaction.editReply({
        embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle(`📝 ${song.title}`).setDescription(text).setFooter({ text: "Quelle: Genius" }).setURL(song.url)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [buildErrorEmbed(`Lyrics-Fehler: ${err.message}`)] });
    }
  },
};
