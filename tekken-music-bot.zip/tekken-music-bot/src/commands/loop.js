const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder()
    .setName("loop").setDescription("🔁 Loop-Modus setzen")
    .addStringOption(o => o.setName("modus").setDescription("Modus").setRequired(true)
      .addChoices({ name: "🔇 Aus", value: "off" }, { name: "🔂 Song", value: "song" }, { name: "🔁 Queue", value: "queue" })),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    q.loop = interaction.options.getString("modus");
    await q.updateNowPlaying();
    const msgs = { off: "🔇 Loop **aus**.", song: "🔂 **Song-Loop** an.", queue: "🔁 **Queue-Loop** an." };
    await interaction.reply({ content: msgs[q.loop] });
  },
};
