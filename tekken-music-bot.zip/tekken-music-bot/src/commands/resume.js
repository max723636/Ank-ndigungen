const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("resume").setDescription("▶️ Setzt fort"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    const ok = await q.resume();
    if (ok) await q.updateNowPlaying();
    await interaction.reply({ content: ok ? `▶️ **${q.current.title}** fortgesetzt.` : "❌ Läuft bereits!", flags: ok ? undefined : 64 });
  },
};
