const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("back").setDescription("⏮️ Vorheriger Song"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.history?.length) return interaction.reply({ embeds: [buildErrorEmbed("Kein vorheriger Song!")], flags: 64 });
    const prev = q.history.pop();
    const res  = await q._raw.search({ query: prev.url }, interaction.user).catch(() => null);
    if (res?.tracks?.[0]) {
      q._raw.queue.tracks.unshift(res.tracks[0]);
      q.skip();
      await interaction.reply({ content: `⏮️ Zurück zu **${prev.title}**!` });
    } else {
      await interaction.reply({ embeds: [buildErrorEmbed("Konnte Song nicht erneut laden!")], flags: 64 });
    }
  },
};
