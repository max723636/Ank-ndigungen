const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder()
    .setName("volume").setDescription("🔊 Lautstärke (0-150)")
    .addIntegerOption(o => o.setName("wert").setDescription("Lautstärke %").setRequired(true).setMinValue(0).setMaxValue(150)),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    const vol = interaction.options.getInteger("wert");
    q.setVolume(vol);
    await q.updateNowPlaying();
    const e = vol === 0 ? "🔇" : vol < 50 ? "🔈" : vol < 100 ? "🔉" : "🔊";
    await interaction.reply({ content: `${e} Lautstärke auf **${vol}%** gesetzt.` });
  },
};
