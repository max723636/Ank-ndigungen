const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("shuffle").setDescription("🔀 Shuffle an/aus"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    q.shuffle = !q.shuffle;
    if (q.shuffle) q.shuffleQueue();
    await q.updateNowPlaying();
    await interaction.reply({ content: q.shuffle ? "🔀 Shuffle **aktiviert**! Queue gemischt." : "🔀 Shuffle **deaktiviert**!" });
  },
};
