const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const config = require("../config");
const { version: djsV } = require("discord.js");
const { getLavalink, isNodeConnected } = require("../utils/LavalinkManager");

module.exports = {
  data: new SlashCommandBuilder().setName("about").setDescription("ℹ️ Bot-Informationen"),
  async execute(interaction, client) {
    const uptime = _fmt(client.uptime);
    const lavalink = getLavalink();
    const active = lavalink ? lavalink.players.size : 0;
    const connected = isNodeConnected();

    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(config.COLORS.ABOUT)
        .setAuthor({ name: config.BOT_NAME, iconURL: client.user.displayAvatarURL() })
        .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
        .setDescription(`**${config.BOT_NAME}** – Discord Musik-Bot mit YouTube, Spotify & echten Audiofiltern. Architektur inspiriert von BeatDock.`)
        .addFields(
          { name: "📊 General", value: `**Version:** ${config.BOT_VERSION}\n**Backend:** 🔗 lavalink-client\n**Node-Status:** ${connected ? "🟢 Verbunden" : "🔴 Getrennt"}\n**Servers:** ${client.guilds.cache.size}\n**Aktive Player:** ${active}`, inline: false },
          { name: "📈 Latency", value: `**API:** ${client.ws.ping}ms`, inline: false },
          { name: "⚙️ System",  value: `**Uptime:** ${uptime}\n**Node.js:** v${process.version.slice(1)}\n**Discord.js:** v${djsV}\n**Platform:** ${process.platform}`, inline: false },
        )
        .setFooter({ text: `${config.BOT_NAME} – High-Quality Music Experience`, iconURL: client.user.displayAvatarURL() })
        .setTimestamp()],
    });
  },
};
function _fmt(ms) {
  const s=Math.floor(ms/1000), m=Math.floor(s/60), h=Math.floor(m/60), d=Math.floor(h/24);
  const p=[]; if(d)p.push(`${d}d`); if(h%24)p.push(`${h%24}h`); if(m%60)p.push(`${m%60}m`); p.push(`${s%60}s`);
  return p.join(" ");
}
