const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("clear").setDescription("🗑️ Queue leeren (Song läuft weiter)"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q) return interaction.reply({ embeds: [buildErrorEmbed("Keine Queue!")], flags: 64 });
    const count = q.getSongCount();
    q._raw.queue.tracks.splice(0, count);
    await q.updateNowPlaying();
    await interaction.reply({ content: count > 0 ? `🗑️ **${count}** Songs entfernt!` : "🗑️ Queue war leer!" });
  },
};
