const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("leave").setDescription("👋 Bot verlässt den Sprachkanal"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q) return interaction.reply({ embeds: [buildErrorEmbed("Ich bin in keinem Voice-Channel!")], flags: 64 });
    q.destroy();
    await interaction.reply({ content: "👋 Bis bald! Verlasse den Sprachkanal." });
  },
};
