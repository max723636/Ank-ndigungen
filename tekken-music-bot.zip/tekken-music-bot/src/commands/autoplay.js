const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("autoplay").setDescription("➡️ Autoplay an/aus"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q) return interaction.reply({ embeds: [buildErrorEmbed("Keine Queue!")], flags: 64 });
    q.autoplay = !q.autoplay;
    await q.updateNowPlaying();
    await interaction.reply({ content: q.autoplay ? "➡️ Autoplay **an**!" : "➡️ Autoplay **aus**!" });
  },
};
