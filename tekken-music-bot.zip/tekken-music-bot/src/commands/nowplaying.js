const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildNowPlayingEmbed, buildPlayerButtons, buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder().setName("nowplaying").setDescription("🎵 Aktuellen Song anzeigen"),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
    const msg = await interaction.reply({
      embeds: [buildNowPlayingEmbed(q.current, q)], components: buildPlayerButtons(q), fetchReply: true,
    });
    if (q._raw) q._raw._npMsgId = msg.id;
  },
};
