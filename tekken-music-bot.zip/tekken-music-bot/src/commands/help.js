const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const config = require("../config");

const CATEGORIES = {
  music: {
    emoji: "🎵", label: "Music",
    fields: [
      ["/play <query>",   "Spielt einen Song – YouTube, Spotify, Shorts, Playlist"],
      ["/search <query>", "Sucht Songs und zeigt eine Auswahlliste"],
      ["/replay",         "Startet den aktuellen Song von vorne"],
      ["/lyrics [song]",  "Zeigt die Songtexte"],
      ["/favorite",       "Aktuellen Song favorisieren/entfavorisieren"],
      ["/favorites",      "Zeigt deine Lieblingssongs"],
    ],
  },
  queue: {
    emoji: "📋", label: "Queue",
    fields: [
      ["/queue [seite]", "Zeigt die aktuelle Warteschlange"],
      ["/skip [anzahl]", "Überspringt einen oder mehrere Songs"],
      ["/back",          "Spielt den vorherigen Song erneut"],
      ["/clear",         "Leert die Queue (Song läuft weiter)"],
      ["/shuffle",       "Mischt die Warteschlange"],
      ["/loop <modus>",  "Wiederholt Song oder Queue"],
      ["/autoplay",      "Spielt automatisch ähnliche Songs weiter"],
    ],
  },
  controls: {
    emoji: "🎛️", label: "Controls",
    fields: [
      ["/pause",        "Pausiert die Wiedergabe"],
      ["/resume",       "Setzt die Wiedergabe fort"],
      ["/stop",         "Stoppt Musik und leert die Queue"],
      ["/volume <0-150>","Stellt die Lautstärke ein"],
      ["/filter",       "Wendet Audiofilter an (Nightcore, Bass Boost, ...)"],
      ["/leave",        "Bot verlässt den Sprachkanal"],
      ["/247",          "Dauerbetrieb an/aus (Bot bleibt permanent)"],
      ["/nowplaying",   "Zeigt den aktuellen Song erneut an"],
    ],
  },
  utility: {
    emoji: "🔧", label: "Utility",
    fields: [
      ["/about",  "Bot-Informationen und Status"],
      ["/invite", "Einladungslink für den Bot"],
      ["/help",   "Diese Übersicht"],
    ],
  },
};

function buildEmbed(key) {
  const cat = CATEGORIES[key];
  return new EmbedBuilder()
    .setColor(config.COLORS.DEFAULT)
    .setTitle(`${cat.emoji} ${cat.label} Commands`)
    .setDescription(cat.fields.map(([cmd, desc]) => `**${cmd}**\n${desc}`).join("\n\n"))
    .setFooter({ text: `${config.BOT_NAME} • Wähle eine Kategorie unten` });
}

function buildButtons(activeKey) {
  const row = new ActionRowBuilder();
  for (const key of Object.keys(CATEGORIES)) {
    const cat = CATEGORIES[key];
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`help_${key}`)
        .setLabel(cat.label)
        .setEmoji(cat.emoji)
        .setStyle(key === activeKey ? ButtonStyle.Primary : ButtonStyle.Secondary)
    );
  }
  return [row];
}

module.exports = {
  data: new SlashCommandBuilder().setName("help").setDescription("📖 Übersicht aller Befehle"),

  async execute(interaction, client) {
    await interaction.reply({
      embeds:     [buildEmbed("music")],
      components: buildButtons("music"),
      flags: 64,
    });
  },

  async handleButton(interaction, client) {
    const key = interaction.customId.replace("help_", "");
    if (!CATEGORIES[key]) return;
    await interaction.update({ embeds: [buildEmbed(key)], components: buildButtons(key) });
  },
};
