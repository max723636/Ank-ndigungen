const { SlashCommandBuilder } = require("discord.js");
const { getPlayer } = require("../utils/LavalinkManager");
const { buildErrorEmbed } = require("../utils/EmbedBuilder");
module.exports = {
  data: new SlashCommandBuilder()
    .setName("skip").setDescription("⏭️ Überspringt Songs")
    .addIntegerOption(o => o.setName("anzahl").setDescription("Anzahl").setMinValue(1).setMaxValue(50)),
  async execute(interaction, client) {
    const q = getPlayer(interaction.guildId, client);
    if (!q?.current) return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });

    const requested = interaction.options.getInteger("anzahl") || 1;
    const title     = q.current.title;
    // Nie mehr entfernen als tatsächlich in der Queue liegt (+ aktueller Song)
    const n = Math.min(requested, q.getSongCount() + 1);

    try {
      if (n > 1) q._raw.queue.tracks.splice(0, n - 1);
      q.skip();
      await interaction.reply({ content: n > 1 ? `⏭️ **${n}** Songs übersprungen!` : `⏭️ **${title}** übersprungen!` });
    } catch (err) {
      console.error("[Skip Error]", err.message);
      await interaction.reply({ embeds: [buildErrorEmbed("Konnte nicht überspringen!")], flags: 64 });
    }
  },
};
