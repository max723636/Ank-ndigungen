const { buildQueueEmbed, buildErrorEmbed } = require("../utils/EmbedBuilder");
const { getPlayer } = require("../utils/LavalinkManager");

async function handleButton(interaction, client) {
  const queue = getPlayer(interaction.guildId, client);

  if (interaction.customId === "player_queue") {
    if (!queue) return interaction.reply({ embeds: [buildErrorEmbed("Keine Queue!")], flags: 64 });
    return interaction.reply({ embeds: [buildQueueEmbed(queue, 0)], flags: 64 });
  }

  if (!queue?.current) {
    return interaction.reply({ embeds: [buildErrorEmbed("Nichts läuft!")], flags: 64 });
  }

  const member = interaction.guild.members.cache.get(interaction.user.id);
  const userCh = member?.voice?.channelId;
  const botCh  = queue._raw?.voiceChannelId;
  if (botCh && userCh !== botCh) {
    return interaction.reply({ embeds: [buildErrorEmbed("Du musst im selben Voice-Channel sein!")], flags: 64 });
  }

  await interaction.deferUpdate();

  switch (interaction.customId) {
    case "player_pause": {
      const ok = await queue.pause();
      if (!ok) { await interaction.followUp({ content: "❌ Läuft nicht!", flags: 64 }); break; }
      await queue.updateNowPlaying();
      break;
    }
    case "player_resume": {
      const ok = await queue.resume();
      if (!ok) { await interaction.followUp({ content: "❌ Nicht pausiert!", flags: 64 }); break; }
      await queue.updateNowPlaying();
      break;
    }
    case "player_skip":
      queue.skip();
      await interaction.followUp({ content: "⏭️ Übersprungen!", flags: 64 });
      break;
    case "player_stop":
      queue.stop();
      await interaction.followUp({ content: "⏹️ Gestoppt!", flags: 64 });
      break;
    case "player_back": {
      if (!queue.history?.length) { await interaction.followUp({ content: "⏮️ Kein vorheriger Song!", flags: 64 }); break; }
      const prev = queue.history.pop();
      const res  = await queue._raw.search({ query: prev.url }, interaction.user).catch(() => null);
      if (res?.tracks?.[0]) {
        queue._raw.queue.tracks.unshift(res.tracks[0]);
        queue.skip();
        await interaction.followUp({ content: `⏮️ Zurück zu **${prev.title}**!`, flags: 64 });
      }
      break;
    }
    case "player_shuffle":
      queue.shuffle = !queue.shuffle;
      if (queue.shuffle) queue.shuffleQueue();
      await interaction.followUp({ content: queue.shuffle ? "🔀 Shuffle **an**!" : "🔀 Shuffle **aus**!", flags: 64 });
      await queue.updateNowPlaying();
      break;
    case "player_autoplay":
      queue.autoplay = !queue.autoplay;
      await interaction.followUp({ content: queue.autoplay ? "➡️ Autoplay **an**!" : "➡️ Autoplay **aus**!", flags: 64 });
      await queue.updateNowPlaying();
      break;
    case "player_clear": {
      const count = queue.getSongCount();
      queue._raw.queue.tracks.splice(0, count);
      await interaction.followUp({ content: `🗑️ **${count}** Songs entfernt!`, flags: 64 });
      await queue.updateNowPlaying();
      break;
    }
  }
}

module.exports = { handleButton };
