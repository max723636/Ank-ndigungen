/**
 * Lädt eine LIVE, ständig aktuelle Liste öffentlicher Lavalink-Nodes.
 * Genau wie BeatDock: https://lavalink-list.ajieblogs.eu.org/All
 * Kein hardcoded/veralteter Node mehr - die Liste wird alle 10 Min neu geladen.
 */
const REFRESH_INTERVAL_MS = 10 * 60 * 1000;
const FETCH_TIMEOUT_MS    = 10000;
const API_URL = "https://lavalink-list.ajieblogs.eu.org/All";

class PublicNodeProvider {
  constructor() {
    this.nodes = [];
    this.currentIndex = 0;
    this.refreshInterval = null;
  }

  async fetchNodes() {
    let timeout;
    try {
      const controller = new AbortController();
      timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

      const response = await fetch(API_URL, { signal: controller.signal });
      if (!response.ok) throw new Error(`API returned ${response.status}`);

      const data = await response.json();
      if (!Array.isArray(data)) throw new Error("Unerwartetes API-Format");

      const v4Nodes = data.filter(n =>
        n && n.version === "v4" && n.host && n.port && n.password
      );

      const secureNodes = v4Nodes.filter(n => n.secure === true);
      const finalNodes  = secureNodes.length > 0 ? secureNodes : v4Nodes;

      if (finalNodes.length === 0) {
        console.warn("[PublicNodes] Keine v4 Nodes gefunden");
        return this.nodes.length > 0;
      }

      this.nodes = finalNodes;
      this.currentIndex = 0;
      console.log(`[PublicNodes] ✅ ${finalNodes.length} Nodes geladen (${secureNodes.length} davon SSL)`);
      return true;

    } catch (err) {
      if (this.nodes.length > 0) {
        console.warn("[PublicNodes] Refresh fehlgeschlagen, nutze Cache:", err.message);
        return true;
      }
      console.error("[PublicNodes] ❌ Konnte Nodes nicht laden:", err.message);
      return false;
    } finally {
      clearTimeout(timeout);
    }
  }

  getNextNode() {
    if (this.nodes.length === 0) return null;
    const node = this.nodes[this.currentIndex];
    this.currentIndex = (this.currentIndex + 1) % this.nodes.length;
    return {
      host: node.host,
      port: node.port,
      authorization: node.password,
      secure: node.secure === true,
      id: "main-node",
    };
  }

  hasNodes() { return this.nodes.length > 0; }

  startAutoRefresh() {
    if (this.refreshInterval) return;
    this.refreshInterval = setInterval(() => this.fetchNodes(), REFRESH_INTERVAL_MS);
  }

  destroy() {
    if (this.refreshInterval) { clearInterval(this.refreshInterval); this.refreshInterval = null; }
  }
}

module.exports = PublicNodeProvider;
