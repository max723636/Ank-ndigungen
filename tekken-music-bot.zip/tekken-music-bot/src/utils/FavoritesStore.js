/**
 * Einfache JSON-Datei-basierte Speicherung für Lieblingssongs pro Nutzer.
 * Überlebt Bot-Neustarts, da die Datei auf der Festplatte liegt.
 */
const fs   = require("fs");
const path = require("path");

const DATA_DIR  = path.join(__dirname, "../../data");
const DATA_FILE = path.join(DATA_DIR, "favorites.json");
const MAX_PER_USER = 100;

function _ensureFile() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "{}");
}

function _load() {
  _ensureFile();
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return {}; }
}

function _save(data) {
  _ensureFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getFavorites(userId) {
  return _load()[userId] || [];
}

function isFavorite(userId, url) {
  return getFavorites(userId).some(f => f.url === url);
}

function addFavorite(userId, song) {
  const data = _load();
  if (!data[userId]) data[userId] = [];
  if (data[userId].some(f => f.url === song.url)) return false;
  data[userId].unshift({
    title: song.title, artist: song.artist,
    url: song.url, thumbnail: song.thumbnail || null,
    addedAt: Date.now(),
  });
  if (data[userId].length > MAX_PER_USER) data[userId] = data[userId].slice(0, MAX_PER_USER);
  _save(data);
  return true;
}

function removeFavorite(userId, url) {
  const data = _load();
  if (!data[userId]) return false;
  const before = data[userId].length;
  data[userId] = data[userId].filter(f => f.url !== url);
  _save(data);
  return data[userId].length < before;
}

function toggleFavorite(userId, song) {
  if (isFavorite(userId, song.url)) { removeFavorite(userId, song.url); return false; }
  addFavorite(userId, song);
  return true;
}

module.exports = { getFavorites, isFavorite, addFavorite, removeFavorite, toggleFavorite };
