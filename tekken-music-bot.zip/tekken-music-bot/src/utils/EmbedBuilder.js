const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const config = require("../config");

function formatDuration(sec) {
  if (!sec || sec === 0) return "🔴 LIVE";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`
    : `${m}:${String(s).padStart(2,"0")}`;
}

// ─── Now Playing Embed (BeatDock-Style) ───────────────────────────
function buildNowPlayingEmbed(song, queue) {
  const loopLabel = { off: "Aus", song: "🔂 Song", queue: "🔁 Queue" }[queue.loop] || "Aus";
  const color     = song.source === "spotify" ? "#1DB954" : "#FF0000";

  const embed = new EmbedBuilder()
    .setColor(color)
    .setAuthor({ name: "🎵 Music Player" })
    .setDescription(`**Now playing:**\n[${song.title}](${song.url || "https://discord.com"})`)
    .addFields(
      { name: "👤 Artist",   value: song.artist || "Unbekannt",         inline: true },
      { name: "⏱️ Duration", value: formatDuration(song.duration),      inline: true },
      { name: "🎵 In queue", value: `${queue.getSongCount?.() ?? queue.songs?.length ?? 0} songs`, inline: true },
      { name: "👤 Added by", value: `@${song.requestedBy || "Unbekannt"}`, inline: false },
    )
    .setFooter({ text: `Volume: ${queue.getVolume?.() ?? 80}% | Loop: ${loopLabel} | Shuffle: ${queue.shuffle ? "An" : "Aus"}` })
    .setTimestamp();

  if (song.thumbnail) embed.setThumbnail(song.thumbnail);
  return embed;
}

// ─── Buttons – Reihe 1+2 wie Screenshot ──────────────────────────
function buildPlayerButtons(queue) {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("player_back")
      .setEmoji("⏮️")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(!queue.history?.length),

    new ButtonBuilder()
      .setCustomId(queue.paused ? "player_resume" : "player_pause")
      .setEmoji(queue.paused ? "▶️" : "⏸️")
      .setStyle(ButtonStyle.Primary),

    new ButtonBuilder()
      .setCustomId("player_skip")
      .setEmoji("⏭️")
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId("player_stop")
      .setEmoji("⏹️")
      .setStyle(ButtonStyle.Danger),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("player_shuffle")
      .setEmoji("🔀")
      .setStyle(queue.shuffle ? ButtonStyle.Success : ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId("player_autoplay")
      .setEmoji("➡️")
      .setStyle(queue.autoplay ? ButtonStyle.Success : ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId("player_queue")
      .setEmoji("📋")
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId("player_clear")
      .setEmoji("🗑️")
      .setStyle(ButtonStyle.Secondary),
  );

  return [row1, row2];
}

// ─── Queue Embed ──────────────────────────────────────────────────
function buildQueueEmbed(queue, page = 0) {
  const perPage = 10;
  const songs   = queue.songs || [];
  const start   = page * perPage;
  const chunk   = songs.slice(start, start + perPage);
  const pages   = Math.ceil(songs.length / perPage) || 1;

  let desc = queue.current
    ? `**▶️ Jetzt:** [${queue.current.title}](${queue.current.url || "#"}) \`[${formatDuration(queue.current.duration)}]\`\n\n`
    : "";

  desc += chunk.length
    ? "**📋 Als nächstes:**\n" + chunk.map((s, i) =>
        `\`${start + i + 1}.\` [${s.title}](${s.url || "#"}) \`[${formatDuration(s.duration)}]\``
      ).join("\n")
    : "*Queue ist leer!*";

  return new EmbedBuilder()
    .setColor(config.COLORS.QUEUE)
    .setTitle("📋 Song Queue")
    .setDescription(desc)
    .setFooter({ text: `Seite ${page+1}/${pages} • ${songs.length} Songs • Loop: ${queue.loop} • Shuffle: ${queue.shuffle ? "An" : "Aus"}` });
}

function buildErrorEmbed(msg) {
  return new EmbedBuilder().setColor(config.COLORS.ERROR).setDescription(`❌ ${msg}`);
}

function buildSuccessEmbed(msg) {
  return new EmbedBuilder().setColor(config.COLORS.SUCCESS).setDescription(`✅ ${msg}`);
}

function buildAddedEmbed(song, pos, queue) {
  const e = new EmbedBuilder()
    .setColor(song.source === "spotify" ? "#1DB954" : config.COLORS.DEFAULT)
    .setDescription(`✅ **[${song.title}](${song.url || "#"})** zur Queue hinzugefügt!`)
    .addFields(
      { name: "👤 Artist",   value: song.artist || "Unbekannt", inline: true },
      { name: "⏱️ Dauer",   value: formatDuration(song.duration), inline: true },
      { name: "📋 Position", value: `#${pos}`, inline: true },
    );
  if (song.thumbnail) e.setThumbnail(song.thumbnail);
  return e;
}

module.exports = { buildNowPlayingEmbed, buildPlayerButtons, buildQueueEmbed, buildErrorEmbed, buildSuccessEmbed, buildAddedEmbed, formatDuration };
