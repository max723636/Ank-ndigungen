const { Client, GatewayIntentBits, Collection, Events, ActivityType, REST, Routes } = require("discord.js");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });
const fs     = require("fs");
const config = require("./config");
const { initLavalink, getLavalink } = require("./utils/LavalinkManager");
const { handleButton } = require("./handlers/buttonHandler");

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});

module.exports = { client };
client.commands  = new Collection();
client.startTime = Date.now();

// ─── ENTSCHEIDEND: Rohdaten von Discord an Lavalink weiterleiten ──────
// Ohne das bekommt Lavalink nie VOICE_SERVER_UPDATE/VOICE_STATE_UPDATE -
// der Track "läuft" laut Lavalink, aber es wird nie eine echte Audio-
// Verbindung zu Discords Voice-Servern aufgebaut (daher: Stille).
client.on("raw", (d) => {
  const lavalink = getLavalink();
  if (lavalink) lavalink.sendRawData(d);
});

const cmdPath = path.join(__dirname, "commands");
for (const file of fs.readdirSync(cmdPath).filter(f => f.endsWith(".js"))) {
  try {
    const cmd = require(path.join(cmdPath, file));
    if (cmd.data && cmd.execute) client.commands.set(cmd.data.name, cmd);
  } catch (err) { console.error(`[CMD] ${file}: ${err.message}`); }
}

async function registerCommands() {
  const rest    = new REST({ version: "10" }).setToken(config.TOKEN);
  const cmdJson = [...client.commands.values()].map(c => c.data.toJSON());
  try {
    if (config.GUILD_ID) {
      await rest.put(Routes.applicationGuildCommands(config.CLIENT_ID, config.GUILD_ID), { body: cmdJson });
      console.log(`✅ ${cmdJson.length} Commands registriert (sofort aktiv)!`);
    } else {
      await rest.put(Routes.applicationCommands(config.CLIENT_ID), { body: cmdJson });
      console.log(`✅ ${cmdJson.length} globale Commands registriert!`);
    }
  } catch (err) {
    console.error("❌ Commands-Fehler:", err.message);
  }
}

client.once(Events.ClientReady, async () => {
  console.log(`\n✅ ${client.user.tag} ist online!`);
  console.log(`📡 ${client.guilds.cache.size} Server | ${client.commands.size} Commands`);
  console.log(`🔗 Backend: lavalink-client (BeatDock-Architektur, live Node-Liste)`);
  console.log("");

  await registerCommands();

  try {
    await initLavalink(client);
  } catch (err) {
    console.error("[Lavalink Init]", err.message);
  }

  client.user.setActivity("🎵 /play", { type: ActivityType.Listening });
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isChatInputCommand()) {
    const cmd = client.commands.get(interaction.commandName);
    if (!cmd) return;
    try {
      await cmd.execute(interaction, client);
    } catch (err) {
      console.error(`[ERROR] /${interaction.commandName}:`, err.message);
      const msg = { content: "❌ Fehler beim Ausführen!", flags: 64 };
      if (interaction.replied || interaction.deferred) await interaction.followUp(msg).catch(() => {});
      else await interaction.reply(msg).catch(() => {});
    }
  }
  if (interaction.isButton()) {
    const id = interaction.customId;
    if (id.startsWith("help_")) {
      await client.commands.get("help")?.handleButton?.(interaction, client).catch(console.error);
    } else if (id.startsWith("favprev_") || id.startsWith("favnext_")) {
      await client.commands.get("favorites")?.handleButton?.(interaction, client).catch(console.error);
    } else {
      await handleButton(interaction, client).catch(console.error);
    }
  }
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId === "search_select") await client.commands.get("search")?.handleSelect?.(interaction, client).catch(console.error);
    if (interaction.customId === "filter_select") await client.commands.get("filter")?.handleSelect?.(interaction, client).catch(console.error);
    if (interaction.customId.startsWith("favplay_")) await client.commands.get("favorites")?.handleSelect?.(interaction, client).catch(console.error);
  }
});

process.on("unhandledRejection", err => console.error("[UNHANDLED]", err?.message || err));
client.login(config.TOKEN);
