const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

const required = ["TOKEN", "CLIENT_ID"];
const missing  = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("\n❌ Fehlende Pflichtfelder in .env:");
  missing.forEach(k => console.error(`   → ${k}`));
  process.exit(1);
}

module.exports = {
  TOKEN:     process.env.TOKEN,
  CLIENT_ID: process.env.CLIENT_ID,
  GUILD_ID:  process.env.GUILD_ID?.trim() || "",

  GENIUS_TOKEN:     process.env.GENIUS_TOKEN || "",
  DEFAULT_VOLUME:   parseInt(process.env.DEFAULT_VOLUME || "80"),
  AUTOPLAY_DEFAULT: process.env.AUTOPLAY_DEFAULT === "true",

  // Leer lassen = automatisch live öffentliche Nodes laden (wie BeatDock)
  LAVALINK_HOST:     process.env.LAVALINK_HOST?.trim() || "",
  LAVALINK_PORT:     parseInt(process.env.LAVALINK_PORT || "2333"),
  LAVALINK_PASSWORD: process.env.LAVALINK_PASSWORD || "youshallnotpass",

  QUEUE_EMPTY_TIMEOUT: parseInt(process.env.QUEUE_EMPTY_TIMEOUT || "30000"),

  COLORS: {
    DEFAULT: "#5865F2", SUCCESS: "#57F287",
    ERROR: "#ED4245",   QUEUE: "#5865F2", ABOUT: "#5865F2",
  },
  BOT_VERSION: "v3.1.0",
  BOT_NAME:    "Dresden RP | System",
};
