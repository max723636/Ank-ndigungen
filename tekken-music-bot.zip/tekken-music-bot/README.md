# 🎵 Dresden RP Musik Bot v3.1

Discord Musik-Bot – **1:1 Architektur von [BeatDock](https://github.com/lazaroagomez/BeatDock)** übernommen, da nachweislich auf Katabump funktionierend.

## 🔑 Was diesmal anders ist
- **Library:** `lavalink-client` (Tomato6966) statt Shoukaku/Kazagumo – exakt was BeatDock nutzt
- **Node-Quelle:** Live-API `lavalink-list.ajieblogs.eu.org/All` – IMMER aktuell, kein veralteter hardcoded Node
- **Reconnect:** Exponential Backoff + automatische Node-Rotation bei Ausfall, wie im BeatDock-Original

## 🚀 Setup auf Katabump

### 1. `.env` erstellen
Kopiere `.env.example` → `.env`:
```
TOKEN=dein_bot_token
CLIENT_ID=deine_client_id
GUILD_ID=deine_server_id
```
Lavalink-Felder **leer lassen** – lädt automatisch aktuelle öffentliche Nodes.

### 2. Katabump "ADDITIONAL NODE PACKAGES"
```
discord.js lavalink-client dotenv genius-lyrics
```

### 3. JS FILE
```
tekken-music-bot/src/index.js
```

### 4. Start-Log (Erfolg)
```
✅ Bot ist online!
🔗 Backend: lavalink-client (BeatDock-Architektur, live Node-Liste)
[PublicNodes] ✅ X Nodes geladen
[Lavalink] ✅ Node "main-node" verbunden
```

## 🎮 Commands
`/play` `/search` `/pause` `/resume` `/skip` `/back` `/stop` `/queue` `/nowplaying` `/loop` `/shuffle` `/autoplay` `/volume` `/clear` `/filter` `/lyrics` `/about` `/invite` `/leave` `/replay` `/247` `/favorite` `/favorites` `/help`

### Neu hinzugekommen
| Command | Beschreibung |
|---|---|
| `/leave` | Bot verlässt den Sprachkanal sofort |
| `/replay` | Startet den aktuellen Song von vorne (Seek zu 0:00) |
| `/247` | Dauerbetrieb an/aus - Bot bleibt permanent im Channel, auch bei leerer Queue oder leerem Channel |
| `/favorite` | Aktuellen Song zu deinen persönlichen Favoriten hinzufügen/entfernen (Toggle) |
| `/favorites` | Zeigt deine Lieblingssongs mit Seiten-Navigation und Direkt-Abspielen per Auswahlmenü |
| `/help` | Interaktive Kategorie-Übersicht (Music/Queue/Controls/Utility) mit Buttons |

Favoriten werden dauerhaft in `data/favorites.json` gespeichert und überleben Bot-Neustarts.

## ⚠️ Falls Node-Verbindung weiter instabil ist
Öffentliche Nodes werden von der Community betrieben – bei Ausfall rotiert der Bot automatisch zum nächsten (Health-Check alle 30s). Das ist normal und in der BeatDock-Architektur eingebaut.

---
*Architektur: [BeatDock](https://github.com/lazaroagomez/BeatDock) von lazaroagomez (Apache-2.0)*
